#ifndef JELLYFIN_H
#define JELLYFIN_H

#include <gctypes.h>
#include "config.h"

#define JSON_BUFFER_SIZE 8192

typedef struct {
    jellyfin_config_t *config;
    char access_token[256];
    char user_id[128];
} jellyfin_client_t;

s32 jellyfin_authenticate(jellyfin_client_t *client);
s32 jellyfin_get_libraries(jellyfin_client_t *client);
s32 jellyfin_get_items(jellyfin_client_t *client, const char *parent_id);
void jellyfin_get_stream_url(jellyfin_client_t *client, const char *item_id, 
                              char *url_buffer, int buffer_size);

#endif
