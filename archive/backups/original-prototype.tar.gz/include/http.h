#ifndef HTTP_H
#define HTTP_H

#include <gctypes.h>

#define HTTP_BUFFER_SIZE 4096

typedef struct {
    s32 socket;
    char buffer[HTTP_BUFFER_SIZE];
} http_connection_t;

s32 http_connect(http_connection_t *conn, const char *host, int port);
s32 http_send_request(http_connection_t *conn, const char *method, 
                      const char *path, const char *body, const char *auth_header);
s32 http_receive_response(http_connection_t *conn, char *response_buffer, int buffer_size);
void http_close(http_connection_t *conn);

#endif
