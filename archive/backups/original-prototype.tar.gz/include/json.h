#ifndef JSON_H
#define JSON_H

char* json_find_value(const char *json, const char *key);

#endif
