#ifndef CONFIG_H
#define CONFIG_H

#define CONFIG_PATH "sd:/apps/jellycub/config.ini"
#define MAX_STRING_LEN 256

typedef struct {
    char server_address[MAX_STRING_LEN];
    int server_port;
    char username[MAX_STRING_LEN];
    char password[MAX_STRING_LEN];
    char device_id[64];
    char client_name[64];
    char client_version[16];
} jellyfin_config_t;

int config_load(const char *path, jellyfin_config_t *config);
void config_set_defaults(jellyfin_config_t *config);

#endif
