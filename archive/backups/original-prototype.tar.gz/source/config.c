#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "config.h"

static void trim(char *str) {
    char *start = str;
    char *end;
    
    while(isspace(*start)) start++;
    
    if(*start == 0) {
        *str = 0;
        return;
    }
    
    end = start + strlen(start) - 1;
    while(end > start && isspace(*end)) end--;
    
    *(end + 1) = 0;
    memmove(str, start, end - start + 2);
}

void config_set_defaults(jellyfin_config_t *config) {
    strncpy(config->server_address, "192.168.1.100", MAX_STRING_LEN);
    config->server_port = 8096;
    strncpy(config->username, "user", MAX_STRING_LEN);
    strncpy(config->password, "password", MAX_STRING_LEN);
    strncpy(config->device_id, "gamecube_01", 64);
    strncpy(config->client_name, "JellyCub", 64);
    strncpy(config->client_version, "0.1", 16);
}

int config_load(const char *path, jellyfin_config_t *config) {
    FILE *f;
    char line[512];
    char key[128];
    char value[384];
    
    config_set_defaults(config);
    
    f = fopen(path, "r");
    if (!f) {
        printf("Config file not found, using defaults\n");
        return -1;
    }
    
    while (fgets(line, sizeof(line), f)) {
        trim(line);
        
        if (line[0] == '#' || line[0] == ';' || line[0] == '\0') {
            continue;
        }
        
        char *equals = strchr(line, '=');
        if (!equals) continue;
        
        *equals = '\0';
        strncpy(key, line, sizeof(key) - 1);
        strncpy(value, equals + 1, sizeof(value) - 1);
        
        trim(key);
        trim(value);
        
        if (strcmp(key, "server") == 0) {
            strncpy(config->server_address, value, MAX_STRING_LEN - 1);
        } else if (strcmp(key, "port") == 0) {
            config->server_port = atoi(value);
        } else if (strcmp(key, "username") == 0) {
            strncpy(config->username, value, MAX_STRING_LEN - 1);
        } else if (strcmp(key, "password") == 0) {
            strncpy(config->password, value, MAX_STRING_LEN - 1);
        } else if (strcmp(key, "device_id") == 0) {
            strncpy(config->device_id, value, 63);
        } else if (strcmp(key, "client_name") == 0) {
            strncpy(config->client_name, value, 63);
        }
    }
    
    fclose(f);
    printf("Config loaded from %s\n", path);
    return 0;
}
