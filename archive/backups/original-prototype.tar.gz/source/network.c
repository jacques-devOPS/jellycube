#include <stdio.h>
#include <string.h>
#include <network.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "network.h"

s32 network_init(void) {
    char localip[16] = {0};
    char netmask[16] = {0};
    char gateway[16] = {0};
    
    printf("Initializing network...\n");
    
    if (if_config(localip, netmask, gateway, true, 20) < 0) {
        printf("Error: Network initialization failed\n");
        return -1;
    }
    
    printf("Network initialized\n");
    printf("IP: %s\n", localip);
    printf("Gateway: %s\n", gateway);
    
    return 0;
}

void network_deinit(void) {
    net_deinit();
}
