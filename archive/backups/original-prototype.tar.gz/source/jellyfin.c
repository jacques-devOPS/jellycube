#include <stdio.h>
#include <string.h>
#include "jellyfin.h"
#include "http.h"
#include "json.h"

static void build_auth_header(jellyfin_client_t *client, char *buffer, int size) {
    if (client->access_token[0]) {
        snprintf(buffer, size,
                "X-Emby-Authorization: MediaBrowser Client=\"%s\", Device=\"GameCube\", "
                "DeviceId=\"%s\", Version=\"%s\", Token=\"%s\"\r\n",
                client->config->client_name, client->config->device_id, 
                client->config->client_version, client->access_token);
    } else {
        snprintf(buffer, size,
                "X-Emby-Authorization: MediaBrowser Client=\"%s\", Device=\"GameCube\", "
                "DeviceId=\"%s\", Version=\"%s\"\r\n",
                client->config->client_name, client->config->device_id, 
                client->config->client_version);
    }
}

s32 jellyfin_authenticate(jellyfin_client_t *client) {
    http_connection_t conn = {0};
    char body[512];
    char response[JSON_BUFFER_SIZE];
    char auth_header[512];
    char *token, *userid;
    
    printf("\nAuthenticating with Jellyfin...\n");
    
    snprintf(body, sizeof(body),
            "{\"Username\":\"%s\",\"Pw\":\"%s\"}",
            client->config->username, client->config->password);
    
    build_auth_header(client, auth_header, sizeof(auth_header));
    
    if (http_connect(&conn, client->config->server_address, client->config->server_port) < 0) {
        return -1;
    }
    
    http_send_request(&conn, "POST", "/Users/AuthenticateByName", body, auth_header);
    http_receive_response(&conn, response, sizeof(response));
    http_close(&conn);
    
    token = json_find_value(response, "AccessToken");
    userid = json_find_value(response, "Id");
    
    if (token && userid) {
        strncpy(client->access_token, token, sizeof(client->access_token) - 1);
        strncpy(client->user_id, userid, sizeof(client->user_id) - 1);
        printf("Authentication successful\n");
        return 0;
    }
    
    printf("Authentication failed\n");
    return -1;
}

s32 jellyfin_get_libraries(jellyfin_client_t *client) {
    http_connection_t conn = {0};
    char path[256];
    char response[JSON_BUFFER_SIZE];
    char auth_header[512];
    
    printf("\nFetching libraries...\n");
    
    snprintf(path, sizeof(path), "/Users/%s/Views", client->user_id);
    build_auth_header(client, auth_header, sizeof(auth_header));
    
    if (http_connect(&conn, client->config->server_address, client->config->server_port) < 0) {
        return -1;
    }
    
    http_send_request(&conn, "GET", path, NULL, auth_header);
    http_receive_response(&conn, response, sizeof(response));
    http_close(&conn);
    
    printf("Libraries response:\n%s\n", response);
    
    return 0;
}

s32 jellyfin_get_items(jellyfin_client_t *client, const char *parent_id) {
    http_connection_t conn = {0};
    char path[512];
    char response[JSON_BUFFER_SIZE];
    char auth_header[512];
    
    printf("\nFetching items...\n");
    
    if (parent_id) {
        snprintf(path, sizeof(path), 
                "/Users/%s/Items?ParentId=%s&Limit=10", 
                client->user_id, parent_id);
    } else {
        snprintf(path, sizeof(path), 
                "/Users/%s/Items?Limit=10", 
                client->user_id);
    }
    
    build_auth_header(client, auth_header, sizeof(auth_header));
    
    if (http_connect(&conn, client->config->server_address, client->config->server_port) < 0) {
        return -1;
    }
    
    http_send_request(&conn, "GET", path, NULL, auth_header);
    http_receive_response(&conn, response, sizeof(response));
    http_close(&conn);
    
    printf("Items response:\n%s\n", response);
    
    return 0;
}

void jellyfin_get_stream_url(jellyfin_client_t *client, const char *item_id, 
                              char *url_buffer, int buffer_size) {
    snprintf(url_buffer, buffer_size,
            "http://%s:%d/Videos/%s/stream?"
            "VideoCodec=h264&"
            "AudioCodec=aac&"
            "VideoBitrate=2000000&"
            "AudioBitrate=128000&"
            "MaxWidth=640&"
            "MaxHeight=480&"
            "TranscodingContainer=ts&"
            "TranscodingProtocol=hls&"
            "api_key=%s",
            client->config->server_address, client->config->server_port, 
            item_id, client->access_token);
}
