#include <stdio.h>
#include <stdlib.h>
#include <gccore.h>
#include <fat.h>
#include "config.h"
#include "network.h"
#include "jellyfin.h"

static void *xfb = NULL;
static GXRModeObj *rmode = NULL;

int main(int argc, char **argv) {
    jellyfin_config_t config;
    jellyfin_client_t client = {0};
    
    VIDEO_Init();
    PAD_Init();
    
    rmode = VIDEO_GetPreferredMode(NULL);
    xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
    console_init(xfb, 20, 20, rmode->fbWidth, rmode->xfbHeight, rmode->fbWidth * VI_DISPLAY_PIX_SZ);
    
    VIDEO_Configure(rmode);
    VIDEO_SetNextFramebuffer(xfb);
    VIDEO_SetBlack(FALSE);
    VIDEO_Flush();
    VIDEO_WaitVSync();
    if (rmode->viTVMode & VI_NON_INTERLACE) VIDEO_WaitVSync();
    
    printf("\x1b[2J");
    printf("JellyCub - Jellyfin Client for GameCube\n");
    printf("========================================\n\n");
    
    fatInitDefault();
    
    if (config_load(CONFIG_PATH, &config) < 0) {
        printf("\nUsing default configuration\n");
    }
    
    printf("\nServer: %s:%d\n", config.server_address, config.server_port);
    printf("User: %s\n", config.username);
    
    if (network_init() < 0) {
        printf("\nPress START to exit...\n");
        while(1) {
            VIDEO_WaitVSync();
            PAD_ScanPads();
            if (PAD_ButtonsDown(0) & PAD_BUTTON_START) exit(0);
        }
    }
    
    client.config = &config;
    
    if (jellyfin_authenticate(&client) < 0) {
        printf("\nAuthentication failed\n");
        printf("Check your credentials in config.ini\n");
        printf("\nPress START to exit...\n");
        while(1) {
            VIDEO_WaitVSync();
            PAD_ScanPads();
            if (PAD_ButtonsDown(0) & PAD_BUTTON_START) exit(0);
        }
    }
    
    jellyfin_get_libraries(&client);
    jellyfin_get_items(&client, NULL);
    
    char stream_url[512];
    jellyfin_get_stream_url(&client, "example_item_id", stream_url, sizeof(stream_url));
    printf("\nExample stream URL:\n%s\n", stream_url);
    
    printf("\n========================================\n");
    printf("Demo Complete\n");
    printf("========================================\n");
    printf("\nPress START to return to loader...\n");
    
    while(1) {
        VIDEO_WaitVSync();
        PAD_ScanPads();
        if (PAD_ButtonsDown(0) & PAD_BUTTON_START) {
            network_deinit();
            exit(0);
        }
    }
    
    return 0;
}
