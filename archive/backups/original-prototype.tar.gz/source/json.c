#include <stdio.h>
#include <string.h>
#include "json.h"

char* json_find_value(const char *json, const char *key) {
    static char value[512];
    char search_key[128];
    char *start, *end;
    
    snprintf(search_key, sizeof(search_key), "\"%s\":", key);
    start = strstr(json, search_key);
    
    if (!start) return NULL;
    
    start += strlen(search_key);
    
    while (*start == ' ' || *start == '\t' || *start == '\n') start++;
    
    if (*start == '"') {
        start++;
        end = strchr(start, '"');
        if (!end) return NULL;
        
        int len = end - start;
        if (len >= sizeof(value)) len = sizeof(value) - 1;
        strncpy(value, start, len);
        value[len] = '\0';
        return value;
    }
    
    end = start;
    while (*end && *end != ',' && *end != '}' && *end != '\n') end++;
    
    int len = end - start;
    if (len >= sizeof(value)) len = sizeof(value) - 1;
    strncpy(value, start, len);
    value[len] = '\0';
    
    return value;
}
