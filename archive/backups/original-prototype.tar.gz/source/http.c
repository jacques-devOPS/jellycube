#include <stdio.h>
#include <string.h>
#include <network.h>
#include "http.h"

s32 http_connect(http_connection_t *conn, const char *host, int port) {
    struct sockaddr_in server_addr;
    
    conn->socket = net_socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
    if (conn->socket < 0) {
        printf("Error: Failed to create socket\n");
        return -1;
    }
    
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = inet_addr(host);
    
    printf("Connecting to %s:%d...\n", host, port);
    if (net_connect(conn->socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        printf("Error: Failed to connect\n");
        net_close(conn->socket);
        return -1;
    }
    
    printf("Connected\n");
    return 0;
}

s32 http_send_request(http_connection_t *conn, const char *method, 
                      const char *path, const char *body, const char *auth_header) {
    char request[HTTP_BUFFER_SIZE];
    int len;
    
    if (body) {
        len = snprintf(request, sizeof(request),
                      "%s %s HTTP/1.1\r\n"
                      "%s"
                      "Content-Type: application/json\r\n"
                      "Content-Length: %d\r\n"
                      "Connection: close\r\n"
                      "\r\n"
                      "%s",
                      method, path, auth_header, (int)strlen(body), body);
    } else {
        len = snprintf(request, sizeof(request),
                      "%s %s HTTP/1.1\r\n"
                      "%s"
                      "Connection: close\r\n"
                      "\r\n",
                      method, path, auth_header);
    }
    
    return net_send(conn->socket, request, len, 0);
}

s32 http_receive_response(http_connection_t *conn, char *response_buffer, int buffer_size) {
    s32 total_received = 0;
    s32 bytes_received;
    char *body_start;
    
    memset(response_buffer, 0, buffer_size);
    
    while (total_received < buffer_size - 1) {
        bytes_received = net_recv(conn->socket, 
                                 response_buffer + total_received, 
                                 buffer_size - total_received - 1, 0);
        
        if (bytes_received <= 0) break;
        total_received += bytes_received;
    }
    
    response_buffer[total_received] = '\0';
    
    body_start = strstr(response_buffer, "\r\n\r\n");
    if (body_start) {
        body_start += 4;
        memmove(response_buffer, body_start, strlen(body_start) + 1);
    }
    
    return total_received;
}

void http_close(http_connection_t *conn) {
    if (conn->socket >= 0) {
        net_close(conn->socket);
        conn->socket = -1;
    }
}
